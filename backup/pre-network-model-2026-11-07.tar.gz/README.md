# Bail(ey)ing Out: agent-based evacuation simulator for Bailey Hall

An interactive, research-grade simulator for the CMCM 2026 problem *"Bail(ey)ing Out"*
(evacuating Bailey Hall, Cornell University). Every one of the 1,329 occupants is an
individual agent with its own reaction time, walking speed, behavioural type, knowledge,
social group and route. People move on a reconstruction of the real building, and bottlenecks
emerge from capacity-limited doors, stairs, seat rows and aisles. Monte Carlo batches estimate
the distribution of evacuation times, and an experiment mode compares strategies on common
random seeds.

> Simulated times depend on the documented assumptions (see [docs/PARAMETERS.md](docs/PARAMETERS.md)).
> They are not calibrated predictions and do not prove regulatory compliance or real-world safety.

## Quick start

```bash
npm install
npm run dev          # interactive app at http://localhost:5173
npm run test         # 38 automated tests (vitest)
npm run build        # type-check + production build into dist/
```

Command-line experiments (headless, parallel, reproducible):

```bash
npm run batch -- --scenario concert-emergency --runs 100 --seed 2026 --out results/baseline
npm run batch -- --scenario S4 --runs 200 --set movement.doorFlow=1.6 --set crowdManagers.complianceProb=0.7
npm run experiments -- --runs 40 --seed 2026      # full suite -> docs/RESULTS.md + results/experiments/
npm run geometry                                   # regenerate the geometry JSON from the parametric builder
npx tsx scripts/flow-bound.ts                      # network max-flow / min-cut cross-check
node scripts/ui-check.mjs docs/screenshots         # automated UI check + screenshots (needs npm run dev and Chrome)
```

No API keys, accounts or cloud services are needed. Everything runs locally (Node ≥ 18).

## Using the app

**Left panel (configuration).** Pick a scenario preset, then adjust occupancy, behaviour-type
shares, reaction-time distributions, walking speeds, door and stair capacities, urgency and
faster-is-slower, social influence and knowledge, Crowd Managers (count, posts, compliance,
dynamic re-direction), LED guidance, the zone → exit plans (CM and LED; making them differ
simulates contradictory instructions), closed exits (and how people learn about them),
corridor barriers, and environment or stress tests. Every parameter, including the
route-choice weights per type, can be edited as JSON. Hover ⓘ for sources and units.

**Live simulation.** Start, pause, resume, reset, single-step; speeds 1×–50×; first floor,
balcony, or both side by side; zoom (wheel), pan (drag), fit (double click). Options include
the PDF floor-plan or seating-chart overlay with adjustable opacity, a density heatmap
(current or peak), queue markers at doors and stairs, the walkable network and labels. A
replay slider scrubs through one snapshot per simulated second. Click any circle to inspect
that person: speed, reaction times, type, state, chosen exit and why, known exits and
closures, guidance received, utilities of each exit, current link, density, waiting time,
plus their planned route drawn on the map. When the run ends, the result tiles, evacuation
curve, exit utilisation, start/exit histograms and a bottleneck table appear below the map,
with CSV/JSON exports (agents, time series, run + parameters).

**Monte Carlo.** 1 / 10 / 100 / 500 / custom runs in Web Workers, with progress and cancel.
Shows mean, median, SD, p5–p95, the 95% CI of the mean, P(T ≤ 180 s) with a Wilson CI, and
unresolved and gridlock rates, plus a histogram, mean curve with p5–p95 band, exit
utilisation and queue rankings. Exports CSV/JSON.

**Compare strategies.** Built-in strategies S0–S6 (no guidance; Crowd Managers; + LED;
+ barriers; + both; blocked exit with static or dynamic guidance), the current configuration,
or saved configurations, all run on the same seeds. Gives a side-by-side table, paired
differences with CIs, box plots, benchmark probabilities, mean curves and exit usage. It
flags "faster but denser" strategies.

**Sensitivity.** One-at-a-time low/high sweeps (reaction times, walking speed, door/stair
flow, compliance, habit, headway, groups) with a tornado chart and paired seeds.

**Geometry editor.** Overlay the scanned plans or seating charts, calibrate the overlay
(offset, scale, rotation), drag nodes, edit door/stair widths, highlight approximate
elements, and import/export the geometry JSON, then apply it to all simulations.

## Scenarios

Core: (1) ordinary concert departure, (2) concert emergency with 6 Crowd Managers,
(3a/b/c) blocked foyer connection FC2 (discovered on approach / announced after 45 s /
known immediately), (4) university lecture, (5) corridor barriers, (6) LED guidance, (6b) LED +
barriers. Additional: LED contradicting Crowd Managers, no guidance, 25/50/75% occupancy
(legal CM minimum), one CM absent, older/younger audience, winter, uneven occupancy.
Stress tests (simplified): darkness, smoke, blocked foyer, fire near the stage, falls on
stairs, separated groups and counterflow, highly competitive crowd (faster-is-slower).

## The model in brief

Full specification: [docs/MODEL.md](docs/MODEL.md). Parameters and provenance:
[docs/PARAMETERS.md](docs/PARAMETERS.md).

- **Geometry**: a parametric reconstruction of the first floor and balcony from the PDF plans
  (pages 4–7), stored as editable JSON with 268 nodes, 384 links and 1,329 seats. It includes
  rows, aisles, the 6 access points, the barrier, 9 mezzanine doors, the semicircular
  corridor, 4 portico doors, 3 foyer connections, 5 foyer doors, the monumental and portico
  stairs, two-flight two-lane balcony stairs, stage-side stairwells, stage escape routes,
  3 wheelchair positions and the prohibited elevator. Agents occupy only validated links, so
  they cannot cross walls.
- **Pre-movement**: lognormal recognition, response and preparation phases whose medians
  depend on aisle and door distance, level and familiarity. A social clock dc/dt = 1 + κφ and
  an awareness hazard model neighbours, and Crowd Manager instructions shorten the response.
- **Route choice**: per-agent forward Dijkstra over the links the agent believes open, with
  visible queue delays (narrow doors weigh more) and opposing-flow penalties. A multinomial
  logit over the exit groups it knows uses time, habit (main entrance), visible neighbours'
  choices, accepted guidance and inertia. Six behaviour types differ in their weights.
  Knowledge is local: signs, staff, neighbours, discovery.
- **Movement**: lanes with no overlap and a time-headway following model. Seat rows are
  limited to 0.45 m/s, squeezing past seated people is slower, entrants merge zipper-style at
  junctions, and counterflow keeps each direction to its own side.
- **Bottlenecks**: doors and stairs are token buckets, C = q · w_eff · factors · g(u, π), with a
  testable faster-is-slower term. The throughput limit is verified by the tests.
- **Monte Carlo**: seeded, reproducible, with common random numbers across strategies,
  t-based CIs, Wilson intervals and paired differences. Unfinished runs count as failures.
- **Cross-check**: network max-flow / min-cut bound on the same graph (`QueueModel.ts`).

## Validation and tests

`npm run test` runs 38 tests covering:

- **Occupancy and seating:** occupancy equals the selected value, capacities are respected
  per floor, and each seat is used once.
- **Reproducibility:** the same seed gives identical results, different seeds vary, and the
  audience is identical across interventions.
- **Physical validity:** no link crosses a wall; no teleporting (only adjacent links); stairs
  connect only valid levels and storey stairs are never climbed; nobody uses the elevator.
- **Exits and capacities:** blocked exits never discharge, barriers are never crossed, and
  door/stair throughput never exceeds the capacity rule in any 10 s window.
- **Conservation:** no one is counted as evacuated twice, occupancy is conserved at every
  second, and evacuated counts are monotone.
- **Behaviour and batches:** guidance compliance changes behaviour, and batched runs equal
  individual runs.
- **Explicit failure reporting:** stopped or trapped runs are reported as unresolved, and
  wheelchair users are never counted as safe.
- **Statistics:** t-quantiles, CI coverage, Wilson intervals, paired differences.
- **Flow bound:** the simulated outflow never exceeds the max-flow bound.

The development log with the problems found and fixed is in [docs/PROGRESS.md](docs/PROGRESS.md).

## Results

- [docs/FINDINGS.md](docs/FINDINGS.md): interpretation of the example experiments (key findings and caveats).
- [docs/RESULTS.md](docs/RESULTS.md): all tables, generated by `npm run experiments` (raw CSV/JSON in `results/experiments/`).
- [docs/screenshots/](docs/screenshots/): UI screenshots produced by `scripts/ui-check.mjs`.

Headline (model outputs, 40 paired seeds, full house): concert emergency with 6 Crowd Managers
T = 299 s [291, 306]; without Crowd Managers 366 s; ordinary departure 466 s; lecture 341 s.
The internal orchestra access points (≤ 5.8 p/s) and balcony stairs, not the exterior doors, bind.
Corridor barriers at W1/E1 cut high-density exposure by 57% with a non-significant 9 s time gain;
LED strips add little on top of compliant Crowd Managers.

## Project structure

```text
src/
  geometry/      types.ts, BaileyHallBuilder.ts (parametric reconstruction), NavigationGraph.ts, BaileyHall.ts
  simulation/    Agent, Population, Behavior, Routing, Movement, QueueSystem, Congestion, Guidance,
                 Metrics, SimulationEngine (headless, deterministic), MonteCarlo, QueueModel, Scenarios,
                 Params (all parameters + provenance), Random (seeded xoshiro128**), WorkerPool
  workers/       MonteCarloWorker.ts
  components/    React UI: SimulationCanvas, MapRenderer, LiveController, ControlPanel, StatisticsPanel,
                 AgentInspector, MonteCarloPanel, ExperimentComparison, SensitivityPanel, GeometryEditor, Charts
  data/geometry/ bailey-hall.json (generated, editable)
tests/           vitest suites
scripts/         generate-geometry, batch, run-experiments, flow-bound, ui-check, diagnostics
public/maps/     plan and seating-chart images rendered from the problem PDF
docs/            MODEL.md, PARAMETERS.md, RESULTS.md, PROGRESS.md, screenshots/
results/         CLI and experiment outputs (CSV / JSON)
```

## Limitations (summary)

The geometry comes from scans: about ±6% scale, door widths estimated, backstage routes
schematic. Behaviour is not calibrated to Bailey Hall. The 1D lane model does not represent
contact forces or crush. Smoke, darkness, winter and falls are simplified stress tests.
Assisted evacuation of wheelchair users is not modelled; they are reported as awaiting
assistance, never as safe. The ground level and service spaces are ignored, as the problem
instructs. Read results comparatively, as strategy A versus B under the same assumptions.
